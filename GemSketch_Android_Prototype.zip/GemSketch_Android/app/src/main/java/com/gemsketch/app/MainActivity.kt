package com.gemsketch.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF17211F)
private val Mint = Color(0xFFB9F4D4)
private val Paper = Color(0xFFF5F7F5)
private val Muted = Color(0xFF7A8781)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GemSketchApp() }
    }
}

private enum class Page { Home, Gallery, Studio, Wheel, Shop, Profile, Settings }

@Composable
private fun GemSketchApp() {
    var page by remember { mutableStateOf(Page.Home) }
    var gems by remember { mutableIntStateOf(120) }
    var userName by remember { mutableStateOf("هنرمند") }
    var selectedTile by remember { mutableIntStateOf(0) }
    var menuSound by remember { mutableStateOf(true) }
    var music by remember { mutableStateOf(false) }
    var lastWheel by remember { mutableLongStateOf(0L) }
    var toast by remember { mutableStateOf<String?>(null) }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Ink, onPrimary = Color.White, secondary = Mint,
        background = Paper, surface = Color.White, onSurface = Ink
    )) {
        Scaffold(
            containerColor = Paper,
            topBar = {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 15.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("GemSketch", fontSize = 25.sp, fontWeight = FontWeight.Black, color = Ink)
                        Text("Draw. Learn. Create.", fontSize = 12.sp, color = Muted)
                    }
                    Surface(shape = RoundedCornerShape(50), color = Color.White) {
                        Row(Modifier.padding(horizontal = 13.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Diamond, null, tint = Color(0xFF3F9D78), modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("$gems", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavItem("خانه", Icons.Rounded.Home, page == Page.Home) { page = Page.Home }
                    NavItem("گالری", Icons.Rounded.GridView, page == Page.Gallery) { page = Page.Gallery }
                    NavItem("استودیو", Icons.Rounded.Brush, page == Page.Studio) { page = Page.Studio }
                    NavItem("پروفایل", Icons.Rounded.Person, page == Page.Profile) { page = Page.Profile }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                when (page) {
                    Page.Home -> HomeScreen(gems, userName, { page = Page.Gallery }, { page = Page.Wheel }, { page = Page.Shop }, { page = Page.Settings })
                    Page.Gallery -> GalleryScreen(selectedTile) { selectedTile = it; page = Page.Studio }
                    Page.Studio -> StudioScreen(selectedTile)
                    Page.Wheel -> WheelScreen(
                        canSpin = System.currentTimeMillis() - lastWheel >= 30 * 60 * 1000L,
                        message = toast,
                        onSpin = {
                            val reward = listOf(0, 20, 30, 50, 80, 100, 150).random()
                            gems += reward
                            lastWheel = System.currentTimeMillis()
                            toast = if (reward == 0) "این بار جایزه‌ای نبود؛ بعداً دوباره امتحان کن." else "تبریک! $reward الماس گرفتی."
                        },
                        onShop = { page = Page.Shop }
                    )
                    Page.Shop -> ShopScreen(gems) { toast = "این بسته نمایشی است؛ پرداخت واقعی فعال نیست." }
                    Page.Profile -> ProfileScreen(userName) { userName = it }
                    Page.Settings -> SettingsScreen(menuSound, music, { menuSound = it }, { music = it }, {
                        gems = 120; toast = "نمونه بازنشانی شد."
                    })
                }
            }
        }
    }
}

@Composable
private fun RowScope.NavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    NavigationBarItem(
        selected = selected, onClick = onClick,
        icon = { Icon(icon, contentDescription = label) },
        label = { Text(label, fontSize = 10.sp) },
        colors = NavigationBarItemDefaults.colors(selectedIconColor = Ink, indicatorColor = Mint, selectedTextColor = Ink)
    )
}

@Composable
private fun HomeScreen(gems: Int, userName: String, onGallery: () -> Unit, onWheel: () -> Unit, onShop: () -> Unit, onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("سلام، $userName 👋", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("امروز چیزی تازه بکش.", color = Muted)
        Surface(shape = RoundedCornerShape(28.dp), color = Ink, modifier = Modifier.fillMaxWidth().clickable { onGallery() }) {
            Column(Modifier.padding(22.dp)) {
                Text("وقت خلق کردن است", color = Mint, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text("یک طرح انتخاب کن\nو با سبک خودت بکش.", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold, lineHeight = 32.sp)
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = Mint, shape = RoundedCornerShape(14.dp)) {
                        Row(Modifier.padding(horizontal = 15.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("شروع نقاشی", fontWeight = FontWeight.Bold, color = Ink)
                            Spacer(Modifier.width(8.dp)); Icon(Icons.Rounded.ArrowForward, null, tint = Ink, modifier = Modifier.size(17.dp))
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Rounded.Draw, null, tint = Color.White.copy(alpha = .75f), modifier = Modifier.size(48.dp))
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FeatureCard("گردونه‌ی جایزه", "هر ۳۰ دقیقه", Icons.Rounded.Casino, Modifier.weight(1f), onWheel)
            FeatureCard("فروشگاه", "$gems الماس", Icons.Rounded.Diamond, Modifier.weight(1f), onShop)
        }
        Surface(color = Color.White, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth().clickable { onSettings() }) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(color = Paper, shape = CircleShape, modifier = Modifier.size(44.dp)) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Tune, null) }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("تنظیمات برنامه", fontWeight = FontWeight.Bold)
                    Text("صدا، موسیقی و بازنشانی", fontSize = 12.sp, color = Muted)
                }
                Icon(Icons.Rounded.ChevronRight, null, tint = Muted)
            }
        }
        Text("طرح‌های پیشنهادی", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("🐈", "🌿", "🏔️").forEach { emoji ->
                Surface(color = Color.White, shape = RoundedCornerShape(20.dp), modifier = Modifier.weight(1f).height(95.dp).clickable { onGallery() }) {
                    Box(contentAlignment = Alignment.Center) { Text(emoji, fontSize = 36.sp) }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun FeatureCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(color = Color.White, shape = RoundedCornerShape(22.dp), modifier = modifier.clickable { onClick() }) {
        Column(Modifier.padding(16.dp)) {
            Surface(color = Paper, shape = RoundedCornerShape(14.dp), modifier = Modifier.size(42.dp)) {
                Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = Ink) }
            }
            Spacer(Modifier.height(15.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

private val seedTiles = listOf("🐈","🦊","🐼","🦁","🐯","🐸","🐢","🦋","🐬","🦉","🦄","🐺","🐻","🐧","🦜","🐙","🦌","🐇","🐿️","🦔","🌲","🌵","🌻","🌷","🍄","🌴","🍁","🌾","🌹","🌼","🏔️","🌋","🏝️","🌊","🌙","☀️","⭐","☁️","🌈","🌌","🏠","🏡","🏰","🗼","🌉","⛺","🚲","🚗","🚀","✈️","🎈","🪁","🎨","🎸","🎹","🎧","📷","💎","🪴","🕯️")
private val galleryItems = List(200) { seedTiles[it % seedTiles.size] }

@Composable
private fun GalleryScreen(selected: Int, onSelect: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text("گالری طرح‌ها", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("یک طرح را انتخاب کن تا وارد استودیو شوی.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(3), contentPadding = PaddingValues(bottom = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(galleryItems.indices.toList()) { index ->
                Surface(color = if (selected == index) Mint else Color.White, shape = RoundedCornerShape(18.dp), modifier = Modifier.aspectRatio(1f).clickable { onSelect(index) }) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text(galleryItems[index], fontSize = 34.sp)
                        Text("طرح ${index + 1}", fontSize = 11.sp, color = Muted)
                    }
                }
            }
        }
    }
}

@Composable
private fun StudioScreen(selectedTile: Int) {
    var color by remember { mutableStateOf(Ink) }
    var eraser by remember { mutableStateOf(false) }
    var strokes by remember { mutableStateOf(listOf<List<Offset>>()) }
    var current by remember { mutableStateOf(listOf<Offset>()) }
    var score by remember { mutableIntStateOf(-1) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("استودیوی نقاشی", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("طرح مرجع: ${galleryItems[selectedTile]}  •  مداد آزاد", color = Muted, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !eraser, onClick = { eraser = false }, label = { Text("مداد") }, leadingIcon = { Icon(Icons.Rounded.Edit, null) })
            FilterChip(selected = eraser, onClick = { eraser = true }, label = { Text("پاک‌کن") }, leadingIcon = { Icon(Icons.Rounded.AutoFixNormal, null) })
            FilterChip(selected = color == Color(0xFF279D72), onClick = { color = Color(0xFF279D72); eraser = false }, label = { Text("سبز") })
            FilterChip(selected = color == Color(0xFFE58B48), onClick = { color = Color(0xFFE58B48); eraser = false }, label = { Text("نارنجی") })
        }
        Surface(color = Color.White, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth().weight(1f)) {
            Canvas(Modifier.fillMaxSize().padding(8.dp).pointerInput(eraser, color) {
                detectDragGestures(
                    onDragStart = { current = listOf(it) },
                    onDrag = { change, _ -> current = current + change.position },
                    onDragEnd = { strokes = strokes + listOf(current); current = emptyList() }
                )
            }) {
                (strokes + listOf(current)).forEach { stroke ->
                    if (stroke.size > 1) {
                        val path = Path().apply {
                            moveTo(stroke.first().x, stroke.first().y)
                            stroke.drop(1).forEach { lineTo(it.x, it.y) }
                        }
                        drawPath(path, if (eraser) Color.White else color, style = Stroke(width = if (eraser) 28f else 7f, cap = StrokeCap.Round))
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { strokes = emptyList(); current = emptyList(); score = -1 }, modifier = Modifier.weight(1f)) { Text("پاک کردن بوم") }
            Button(onClick = { score = if (strokes.isEmpty()) 0 else 35 + strokes.sumOf { it.size } % 66 }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Ink)) { Text("مقایسه‌ی آزمایشی") }
        }
        if (score >= 0) Text("امتیاز آزمایشی: $score٪ — هنوز شباهت واقعی تصویر تحلیل نمی‌شود.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun WheelScreen(canSpin: Boolean, message: String?, onSpin: () -> Unit, onShop: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("گردونه‌ی جایزه", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("هر ۳۰ دقیقه یک بار شانس خودت را امتحان کن.", color = Muted, textAlign = TextAlign.Center)
        Box(Modifier.size(250.dp).background(Color.White, CircleShape).border(8.dp, Mint, CircleShape), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.Casino, null, tint = Ink, modifier = Modifier.size(58.dp))
                Text("LUCKY", fontWeight = FontWeight.Black, fontSize = 24.sp)
                Text("20 • 50 • 80 • 150", color = Muted, fontSize = 11.sp)
            }
        }
        Button(onClick = onSpin, enabled = canSpin, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Ink)) {
            Text(if (canSpin) "چرخاندن گردونه" else "هنوز ۳۰ دقیقه نگذشته")
        }
        if (!canSpin) Text("این نسخه‌ی آزمایشی زمان گردونه را به‌صورت پایدار ذخیره نمی‌کند.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
        message?.let { Text(it, color = Muted, textAlign = TextAlign.Center) }
        OutlinedButton(onClick = onShop, modifier = Modifier.fillMaxWidth()) { Text("رفتن به فروشگاه الماس") }
    }
}

@Composable
private fun ShopScreen(gems: Int, onBuy: (Int) -> Unit) {
    val packs = listOf(100 to "۱۰٬۰۰۰ تومان", 300 to "۲۰٬۰۰۰ تومان", 700 to "۳۵٬۰۰۰ تومان", 1500 to "۵۰٬۰۰۰ تومان", 5000 to "۷۵٬۰۰۰ تومان", 10000 to "۱۰۰٬۰۰۰ تومان")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("فروشگاه الماس", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("موجودی فعلی: $gems الماس", color = Muted)
        Spacer(Modifier.height(14.dp))
        Surface(color = Color(0xFFFFF3DD), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Text("حالت نمایشی: این دکمه‌ها پرداخت واقعی انجام نمی‌دهند.", Modifier.padding(14.dp), color = Color(0xFF805A1D), fontSize = 12.sp)
        }
        Spacer(Modifier.height(12.dp))
        packs.forEach { (amount, price) ->
            Surface(color = Color.White, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Diamond, null, tint = Color(0xFF3F9D78), modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("$amount الماس", fontWeight = FontWeight.Bold)
                        Text(price, color = Muted, fontSize = 12.sp)
                    }
                    OutlinedButton(onClick = { onBuy(amount) }) { Text("انتخاب") }
                }
            }
        }
    }
}

@Composable
private fun ProfileScreen(name: String, onName: (String) -> Unit) {
    var draft by remember(name) { mutableStateOf(name) }
    Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("پروفایل", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(30.dp))
        Surface(color = Mint, shape = CircleShape, modifier = Modifier.size(104.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Person, null, tint = Ink, modifier = Modifier.size(58.dp)) }
        }
        Spacer(Modifier.height(20.dp))
        Text("نام نمایشی", color = Muted)
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(value = draft, onValueChange = { draft = it }, singleLine = true, shape = RoundedCornerShape(16.dp))
        Spacer(Modifier.height(12.dp))
        Button(onClick = { onName(draft.ifBlank { "هنرمند" }) }, colors = ButtonDefaults.buttonColors(containerColor = Ink)) { Text("ذخیره‌ی نام") }
        Spacer(Modifier.height(20.dp))
        Text("آواتارهای اختصاصی در نسخه‌ی بعدی اضافه می‌شوند.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun SettingsScreen(menuSound: Boolean, music: Boolean, onSound: (Boolean) -> Unit, onMusic: (Boolean) -> Unit, onReset: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("تنظیمات", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        SettingRow("صدای منو", "صداهای رابط کاربری", menuSound, onSound)
        SettingRow("موسیقی بازی", "موسیقی پس‌زمینه", music, onMusic)
        OutlinedButton(onClick = onReset, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.RestartAlt, null); Spacer(Modifier.width(8.dp)); Text("بازنشانی نمونه")
        }
        Text("این نسخه‌ی اولیه هنوز تنظیمات را به‌صورت دائمی ذخیره نمی‌کند.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Surface(color = Color.White, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, fontSize = 12.sp, color = Muted)
            }
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }
}
